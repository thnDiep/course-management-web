import accountModel from "../models/accountModel.js";
import bcrypt from "bcryptjs";
import sendMail from "../middlewares/email.mdw.js";
let OTP;
let user;
function generateOTP() {
  // Declare a digits variable
  // which stores all digits
  let OTP = "";
  var digits = "0123456789";
  for (let i = 0; i < 4; i++) {
    OTP += digits[Math.floor(Math.random() * 10)];
  }
  return OTP;
}
class AccountController {
  async signUp(req, res) {
    const rawPassword = req.body.password;
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync(rawPassword, salt);
    user = {
      name: req.body.name,
      password: hash,
      email: req.body.email,
      permissionID: 2,
      img: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAMFBMVEXBx9D///+9w83Y3OHDydLIzdXt7/HN0tn3+Pnq7O/S1t319vfh5Ojd4OX8/P3r7fDhTC8lAAAKfElEQVR4nN2d67LrJgyFOWB8wZf9/m9bO44TOzEgoYVNumY6/dHdhC/chJCE+pddU1t3w2hcY21VVWr+x9rGmXHo6nbK//Uq54dP9WBspWepMy3/obJmqLNy5iJsu7FZyM7ZDpwLaWO6NlNLchC2nas83RYA1ZXpcnQmmnCqjWXTvSmtqcENwhJOnVPJeBukch2yTUjCBU9E96Z0f7hmoQhrI+y8D0hlelDLMIQDf2WJQ1rMaAUQTiNodH4xqhGwuIoJe5cH7wnpxINVSJiXD8IoIuyb3HwARgFhm73/3owCky6ZcDJX8T0YzeWEw4V4q4ZLCXt7ZQeu0jZtOiYRXjpAd4xJQzWBsL4Fb1XCyYNPeNkKeqaEbuQS9tWNfIsq7mxkEo53duAqPWYknG5YQr+lLcse5xDeucQcxVlwGIQFjNBNnJFKJ7zEyqZKN3DCyd4N9SHyZCQS9ncDnYi4bdAI/0oaoZs0zSFHIhxKBJwRSccNCmGhgEREAmGxgLRdI05Y0Db4LQJilLBoQApijLDgIboqOhcjhMUDxhHDhF35gDNi+H4jSFj/AuCMGDxqhAj73wCcFXIYBwinu9vNUMAMDxCWdpoIyaYQNuhWPMJKVuEvHP3nRS8hdp+YoRozdHXdt31fd4NppCENn1/g3TN8hMhldAmv+D7MtbDIhvVLfAuqhxC4ymjnX8z/kO5lz2rjIUStMtrGjKoB5qH0rDbnhCBzW1eUcIquAn3buRF+SoiZhJp85TdgVp3zqXhKCLmb0I7ump4w87GiEjrEt0Xs4U9hbHxHI0Q41nTDjfWBOGTP3G8nhIhvSrmthdwsUwiN/Gu4F2BPIcyo75/2ixBwZKL5MfMg6i/j6YtQPh2YawwY8Wvf/ySUf0dyDy6SmxpfX/9JKP0CSfTSIsBOFSaULzP0i71zyWfJx098JGzl80Aa8yo/1eij1+ZIKB4jxBuvkOQGx9GyORDKd4ozs4krsY163DEOhHLXDAAQME4Pa8G+TeIuFOyEe4l3rEMn7gnFXRjw6bEkXk/3nbgjlHchKtNFfJTad+KOULyQoroQcATfrXhvwqmQWbhIPhPfe+KbcBR+KGYh3Zol1duwUTk+VC7xaVh/E2KXaKnE3r73EeNFKF6hTx1dyZK25r3sbYTyrQI5SBHDdBtSCvaJ2NxWsf39+sU3QvnZGpuHLd67XmvNk1DukMVt96vEm/42qJ6EcucB4ty0F6xFKyHgujDNReqX3AB5uhtWQvkgBS80wCathPIhEY7aSRDghs/tCMUf9un+kQvgFFNvQsDvBd4sENvFc1w9CAG3PkUSmhch4OpOh9ubIMAotRshYsiX2Ifr4rAQIm6YyyTsnoSIe/si19LHfrEQIkIvoOffRZDg1molhPxaBdo0ah1ZChXoIbkXPROkpMHyuytIaAL8iA9q1eIdU6goPfT5ENYqBdlaFf6MD2nUYogozEIDP1yAInjnpUbBsiexR2DAAXjR/Lsr1GeBJyKqdMMwE0IiERXYqgFNncWqUbi0CuSOCCvwY2dCWCkP5DCFNar6p3BR+cDVFJgLMSlg+pY0HOotXL6O7hXw54KdL4C/uq5VB/swXCciU646hSxLBpqJ0MTOQUFztTHLKTItUI8Kc0rZPg+xJ2Lz441CmTSrAIYNzJxZ5RQ4kVI+TsGpq41C58JKz/rQWTPLwgmFLil4iQOr4BXmRFsGvgJABkKJaZOhAkCVgTAdMUc1qkxVENMGaqZqVFkYk5abPHVUsoxSleQgzlT2NReh0pZn3bS5ik5W8P3wLY6Nmq/SD37Hf4te2rjOWDXUou3Sg2iVxvNWdm/AZ4sP6XjF+DpzXWKHPR+eSNvBf2cz4WpG+GSwZ/xTad0MZz3ZDxeURJ3P+NeUj9eqGV9PdC2PeI1Npmc/PjVcRLjoUVxoeZfM+4hXDnVIf2mJ0jXS512idA+8tyhTE/DuqUhVyPvDImWBd8BlygHv8cvUCIzFKFL6DxdPU6Ye8TSgmKgypYFxbWVqjWu76eWfS2SA8aVF6hlf+j9eap4xwv9ju+0Z542wanQOyZu1xerLJuJ8qm2cM3g511QyR8Ar3yJ9Imrthj7nq9pTP7j0znzlzKRORNRrrzF1qQ65R4mA9Nw13aCTSPxKcxrvctcSjG9t4Q9oB5Xi+F/r5STmkCbWfpSIP9DWjMHEPOBrO3AV+1G0fR4wc7+oci6ffk28FfGQy807QaHTY+hiHYOeaa0JNRXuA+T14qGmAmeYwnMpOWrpgB91MeirKby0AE+MS4iN7Plv8lqMzsLjinrf+VWfhnp9ga2VlCLiVPyqMURcpm4eo4uI4/SrThQx3gOXUpEuUmzFSa0v0pZYQBdSO/H157yaezduhTtRJtRZzT1KEQN0wnaaCBfzp3UTCXYNvDREmgh9cVr7krBhlDFICcPUU780ukjBc+5TFTVPPDVoo50IrwyRqpgV7a0jHOtEeHWPVMW6wlsLOvZ/FrLQRJeaQD3v2HJ6KUZI4WYGarJHfMP3W92bgtZ3sK5++GzyI4TBtxHC/f8jhB9/y3mj5CcIo2+UhOyFnyCMvjMT2jF+gZDwVlBgsfkFQsJ7T4HF5hcIv/+W8+5a+YTEd9e8lk35hMS387wfUDwh+f1Dn6+ndELGG5aesgaFE3LeIfXt+2U4onzF3FhvyXo+44a77TN57th47wF7pmIRnpr2fIwy33T2meAaXVyer/OUdv/w4r6tru++ufDEKyS8re49ZdwUpvCUx80W8OQGCL35Qjdez/iyJQO/esi75DtIQSoJJckT/BV0cwb9Z757rJvWm97zRHn4zi/sIfT6NKobnMO+xkSGVMQH6kW8fKROvvDEWEtiXl5vIjT/5W2R/nzRwtGfOurH9ud6X3hR439dPm5Ixj31AcTmovCozhvuTbCUCXcRARfqJaZ46w8QpqwGlNuWEGKVffsPlEQgLXek+6TQjWTmcO9QVAJtIaDdmAVDWGgVTJLUefb4VbThQ7wTDFbh0pkYw3yKOHaot55TOP4hw1gdwnyWuh3T73UjKQ+6Qb2Vu2gaw/lAjGMq4+Y6VudFV4FKNCzVsQQSzi7FuZuPh8zpRm7n9CaezsXZoljRB1M8cUUrIxmt/Tz7Yt+hyVPwIWZ8BaEi0dxC1yUN19qEF5fn5zPtKG4ESU0KQtbajn8syn4gFh1iG1H8GBlqbS6tKzfUBMy+Gy01xzDBu5AQBfRHa8yG2ZhhKxB11KNclLOKkUGZYgUnxTlx08geSb22ccaM47jkvzbWVvxU3zSPe1okV5+W1bkSJSaE0osUIgiBT2yQleoYSo/Gu7TYhOBKSBBv2GaueLjjk5xdRBGVeatWvvhk5xZhzGjURr6bT0w492PWsRqvDpqfcJ6PJlMZRK0NwHeAiWzuyGYXgw9UsQEVu0051XHwlEG5RYDR6V0D6sjl+IVrFjT+fuocx44+pcPi/QMTLqpN+pycTyIG7kPPkUPRDi7uizihc10Ot2uuLJG2Gxvq6Wj+u2bMQrcoax5MWw/OPuoG+8hUZd18QM7ZiAsyfZaz/DCux96qWmol2+U0PA7d+dkfrP8AELeBvwZOOcwAAAAASUVORK5CYII=",
    };
    let err_message_name, err_message_email, err_message;
    const check = (name, check) => {
      if (name === check) {
        err_message = `${name} was exist...`;
        return 0;
      }
      return 1;
    };
    const userAvailable = await accountModel.findByUsername(req.body.name);
    const emailAvailable = await accountModel.findByEmail(req.body.email);
    // Đem check tên đã đc tìm trong db vs tên user vừa req lên
    if (
      check(userAvailable?.name, user.name) === 1 &&
      check(emailAvailable?.email, user.email) === 1
    ) {
      OTP = generateOTP();
      const message = {
        to: user.email,
        from: {
          name: "SUN LIGHT",
          email: "manhtu2002227@gmail.com",
        },
        subject: `SEND OTP Student`,
        text: "and easy to do anywhere, even with Node.js",
        html: `<div><strong>OTP:${OTP}</strong></div>`,
      };

      let emailSend = await sendMail(message);
      // res.status(200).send(emailSend);
      return res.render("otp", {
        layout: false,
      });
      // return res.redirect("back");
    } else {
      if (
        check(userAvailable?.name, user.name) == 0 ||
        check(emailAvailable?.email, user.email) == 0
      ) {
        if (check(userAvailable?.name, user.name) == 0) {
          return res.render("signUp", {
            layout: false,
            err_message_name: err_message,
          });
        } else {
          return res.render("signUp", {
            layout: false,
            err_message_email: err_message,
          });
        }
      }
    }
  }
  async login(req, res) {
    const check = (name, chec) => {
      if (name === chec) {
        return 0;
      } else {
        return 1;
      }
    };
    const emailAvailable = await accountModel.findByEmail(req.body.email);
    if (check(emailAvailable?.email, req.body.email) == 1) {
      return res.render("login", {
        layout: false,
        err_message: "Email & password is not correct...",
      });
    } else {
      if (check(emailAvailable?.email, req.body.email) == 0) {
        if (emailAvailable.isActive === 1) {
          // Đúng email rồi so sánh password
          const [passAvailable] = await accountModel.findByEmailToCheckPassword(
            req.body.email
          );
          const ret = bcrypt.compareSync(
            req.body.password,
            passAvailable.password
          );
          if (ret) {
            req.session.isAuthenticated = true;
            // Xét quyền của 3 vai trò
            if (emailAvailable.permissionID == 2) {
              req.session.isStudent = true;
              req.session.authUser = emailAvailable;
              return res.redirect("/");
            } else if (emailAvailable.permissionID == 3) {
              req.session.isTeacher = true;
              req.session.authTeacher = emailAvailable;
              return res.redirect("/teacher/profile");
            } else if (emailAvailable.permissionID == 1) {
              req.session.isAdmin = true;
              req.session.authAdmin = emailAvailable;
              return res.redirect("/admin/listAccount");
            }
          } else {
            return res.render("login", {
              layout: false,
              err_message: "Email & password is not correct...",
            });
          }
        } else {
          return res.render("login", {
            layout: false,
            err_message: "This account has been locked...",
          });
        }
      }
    }
  }
  async otp(req, res) {
    const otpv =
      req.body.input1 + req.body.input2 + req.body.input3 + req.body.input4;
    if (otpv === OTP) {
      await accountModel.add(user);
      res.redirect("/account/login");
    } else {
      return res.render("otp", {
        layout: false,
        err_message: "OTP is not correct",
        input1: req.body.input1,
        input2: req.body.input2,
        input3: req.body.input3,
        input4: req.body.input4,
      });
    }
  }
  async logout(req, res) {
    req.session.authUser = null;
    req.session.authTeacher = null;
    req.session.authAdmin = null;
    req.session.isAuthenticated = false;
    return res.redirect("back");
  }
}

export default new AccountController();
